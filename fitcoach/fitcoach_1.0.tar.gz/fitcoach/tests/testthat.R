library(testthat)
library(fitcoach)

test_check("fitcoach")
